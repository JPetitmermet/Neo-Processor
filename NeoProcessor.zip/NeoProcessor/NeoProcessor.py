#!/usr/bin/env python2.7
import io
import random
import cmath
import numpy
import os
import sys
from numbers import Number
os.chdir(os.path.dirname(sys.argv[0]))

# ----- RX OUTPUT LOADING -----
print("")
print("----- RX OUTPUT LOADING -----")
rxe = dict()
rxl = list()
fcl = list()
etd = dict()
spd = dict()
per = dict()
scount = 0
pcount = 0
fhandle = io.open("rxoutputs.txt")
for line in fhandle:
    tlist = line.strip().split("\t")
    rx = int(tlist[0])
    if rx not in rxl:
        rxl.append(rx)
    if rx not in per and rx != 999:
        sp = str(rx)
        pe = sp[2]
        ip = int(pe)
        per[rx] = ip
    st = str(tlist[1])
    if st not in rxe:
        rxe[st] = dict()
        scount = scount + 1
        etd[st] = list()
    if rx not in etd[st]:
        etd[st].append(rx)
    c = float(tlist[2])
    d = float(tlist[3])
    if c >= d:
        if st not in spd:
            spd[st] = list()
        if rx not in spd[st]:
            spd[st].append(rx)
    e = float(tlist[4])
    f = float(tlist[5])
    g = int(tlist[6])
    h = int(tlist[7])
    i = int(tlist[8])
    j = int(tlist[9])
    k = int(tlist[10])
    l = int(tlist[11])
    if l not in fcl:
        fcl.append(l)
    m = int(tlist[12])
    if m not in fcl:
        fcl.append(m)
    rxe[st][rx] = [rx, st, c, d, e, f, g, h, i, j, k, l, m]
    pcount = pcount + 1
fhandle.close()
print(str(pcount) + " potential states loaded across " + str(scount) + " stands.")       

# ----- KEY FUNCTIONS -----

def genfrags(size, filename, rxe):
    """Splits stands into fragments of the specified size or less. Used in even flow solutions, set
    fragment size to an arbitrarily large number to deal with whole stands. Returns an ordered list with
    frags (dictionary) at [0], nas (dictionary) at [1], frl (list) at [2], fcount (integer) at [3], and
    oac, nac, and tac (floats) at [4], [5], and [6] respectively."""
    print("")
    print("----- FRAGMENTING -----")
    frags = dict()
    nas = dict()
    frl = list()
    fcount = 0
    scount = 0
    ncount = 0
    oac = 0.0
    nac = 0.0
    fhandle = io.open(filename)
    for line in fhandle:
        tlist = line.strip().split("\t")
        st = str(tlist[0])
        if st in rxe:
            net = len(rxe[st])
            cac = float(tlist[1])
            if net > 1:
                oac = oac + cac
                while cac > size:
                    frags[fcount] = [fcount, st, size, 0]
                    frl.append(fcount)
                    fcount = fcount + 1
                    cac = cac - size
                frags[fcount] = [fcount, st, cac, 0]
                frl.append(fcount)
                fcount = fcount + 1
                scount = scount + 1
            elif net == 1:
                ncount = ncount + 1
                nas[st] = cac
                nac = nac + cac
            else:
                print("PROBLEM. BIG PROBLEM")
    tac = oac + nac
    print("{:,}".format(tac) + " acres loaded.")
    print("{:,}".format(oac) + " acres across " + str(scount) + " stands broken into " + "{:,}".format(fcount) + " fragments.")
    print("{:,}".format(nac) + " acres across " + str(ncount) + " stands will not be optimized (no effective treatments).")
    rlist = [frags, nas, frl, fcount, oac, nac, tac]
    return rlist

def evalfrags(frags, rxe, etd, tac, adac, fixc, ents):
    """Identifies all unique fragments and creates per fragment treatment outputs for each of them.
    Returns a dictionary keyed by standID and prescription."""
    print("")
    print("----- EVALUATING FRAGMENTS -----")
    rxf = dict()
    scount = 0
    rcount = 0
    ccount = 0
    for fragment in frags:
        st = frags[fragment][1]
        ac = frags[fragment][2]
        for rx in etd[st]:
            if st not in rxf:
                rxf[st] = dict()
                scount = scount + 1
            if rx not in rxf[st]:
                rxf[st][rx] = dict()
                rcount = rcount + 1
            if ac not in rxf[st][rx]:
                c = rxe[st][rx][2] * ac
                d = rxe[st][rx][3] * ac
                e = rxe[st][rx][4] * ac
                f = rxe[st][rx][5] * ac
                g = rxe[st][rx][6] * ac / tac
                h = rxe[st][rx][7] * ac / tac
                i = rxe[st][rx][8] * ac / tac
                j = rxe[st][rx][9] * ac / tac
                k = rxe[st][rx][10] * ac / tac
                l = rxe[st][rx][11]
                m = rxe[st][rx][12]
                if rx == 999:
                    n = 0
                else:
                    advc = adac * ac
                    if ents <= ac:
                        adfc = fixc
                    else:
                        entc = ac / ents
                        adfc = entc * fixc
                    n = adfc + advc
                rxf[st][rx][ac] = [rx, st, c, d, e, f, g, h, i, j, k, l, m, n]
                ccount = ccount + 1
    print(str(ccount) + " unique fragments identified and evaluated for " + str(scount) + " stands.") 
    return rxf

def pricebio(biop, rxf):
    """Takes the user specified price for biochar feedstock in dollars per green ton and uses it to update the
    fragment output revenues for each unique fragment. Modifies fragment outputs in place and does not return an
    object."""
    totpulp = 0.0
    acount = 0.0
    for stand in rxf:
        for rx in rxf[stand]:
            for ac in rxf[stand][rx]:
                acount = acount + ac
                pulpval = rxf[stand][rx][ac][5] * biop
                totpulp = totpulp + pulpval
                rxf[stand][rx][ac][2] = rxf[stand][rx][ac][2] + pulpval
    avein = totpulp / acount
    print("Biochar feedstock assigned a price of " + str(biop) + " dollars per green ton.")
    print("Biochar feedstock price increased average per acre revenue of unique fragments by " + "{:,}".format(avein) + " dollars.")
                
    
def calccfs(mode, rxe, frags, nas, tac):
    """Calculates the average combined fire score for years 1, 6, 11, 16, and 20. Set mode to 0 to evaluate the
    current solution or set it to 999 to evaluate the no action alternative. Returns a list containing the scores
    in year order for all acres."""
    cfs = [0, 0, 0, 0, 0]
    if mode == 999:
        for stand in nas:
            cfs[0] = cfs[0] + (rxe[stand][999][6] * nas[stand] / tac)
            cfs[1] = cfs[1] + (rxe[stand][999][7] * nas[stand] / tac)
            cfs[2] = cfs[2] + (rxe[stand][999][8] * nas[stand] / tac)
            cfs[3] = cfs[3] + (rxe[stand][999][9] * nas[stand] / tac)
            cfs[4] = cfs[4] + (rxe[stand][999][10] * nas[stand] / tac)
        for fragment in frags:
            cfs[0] = cfs[0] + (rxe[frags[fragment][1]][999][6] * frags[fragment][2] / tac)
            cfs[1] = cfs[1] + (rxe[frags[fragment][1]][999][7] * frags[fragment][2] / tac)
            cfs[2] = cfs[2] + (rxe[frags[fragment][1]][999][8] * frags[fragment][2] / tac)
            cfs[3] = cfs[3] + (rxe[frags[fragment][1]][999][9] * frags[fragment][2] / tac)
            cfs[4] = cfs[4] + (rxe[frags[fragment][1]][999][10] * frags[fragment][2] / tac)
    elif mode == 0:
        for stand in nas:
            cfs[0] = cfs[0] + (rxe[stand][999][6] * nas[stand] / tac)
            cfs[1] = cfs[1] + (rxe[stand][999][7] * nas[stand] / tac)
            cfs[2] = cfs[2] + (rxe[stand][999][8] * nas[stand] / tac)
            cfs[3] = cfs[3] + (rxe[stand][999][9] * nas[stand] / tac)
            cfs[4] = cfs[4] + (rxe[stand][999][10] * nas[stand] / tac)
        for fragment in frags:
            try:
                cfs[0] = cfs[0] + (rxe[frags[fragment][1]][frags[fragment][3]][6] * frags[fragment][2] / tac)
            except:
                print(frags[fragment])
            cfs[1] = cfs[1] + (rxe[frags[fragment][1]][frags[fragment][3]][7] * frags[fragment][2] / tac)
            cfs[2] = cfs[2] + (rxe[frags[fragment][1]][frags[fragment][3]][8] * frags[fragment][2] / tac)
            cfs[3] = cfs[3] + (rxe[frags[fragment][1]][frags[fragment][3]][9] * frags[fragment][2] / tac)
            cfs[4] = cfs[4] + (rxe[frags[fragment][1]][frags[fragment][3]][10] * frags[fragment][2] / tac)
    else:
        print("YOU DUN GOOFED! ENTER VALID MODE")
    return cfs

def calcopcfs(mode, rxe, frags, oac):
    """Calculates the average combined fire score for years 1, 6, 11, 16, and 20. Set mode to 0 to evaluate the
    current solution or set it to 999 to evaluate the no action alternative. Returns a list containing the scores
    in year order. Only measures acres with a valid treatment"""
    cfs = [0, 0, 0, 0, 0]
    if mode == 999:
        for fragment in frags:
            cfs[0] = cfs[0] + (rxe[frags[fragment][1]][999][6] * frags[fragment][2] / oac)
            cfs[1] = cfs[1] + (rxe[frags[fragment][1]][999][7] * frags[fragment][2] / oac)
            cfs[2] = cfs[2] + (rxe[frags[fragment][1]][999][8] * frags[fragment][2] / oac)
            cfs[3] = cfs[3] + (rxe[frags[fragment][1]][999][9] * frags[fragment][2] / oac)
            cfs[4] = cfs[4] + (rxe[frags[fragment][1]][999][10] * frags[fragment][2] / oac)
    elif mode == 0:
        for fragment in frags:
            cfs[0] = cfs[0] + (rxe[frags[fragment][1]][frags[fragment][3]][6] * frags[fragment][2] / oac)
            cfs[1] = cfs[1] + (rxe[frags[fragment][1]][frags[fragment][3]][7] * frags[fragment][2] / oac)
            cfs[2] = cfs[2] + (rxe[frags[fragment][1]][frags[fragment][3]][8] * frags[fragment][2] / oac)
            cfs[3] = cfs[3] + (rxe[frags[fragment][1]][frags[fragment][3]][9] * frags[fragment][2] / oac)
            cfs[4] = cfs[4] + (rxe[frags[fragment][1]][frags[fragment][3]][10] * frags[fragment][2] / oac)
    else:
        print("YOU DUN GOOFED! ENTER VALID MODE")
    return cfs
        
def calcecn(rxe, frags, per):
    """Calculates the economic outputs (revenue and cost) of the current solution given the specified move in cost.
    Move in cost should be in average dollars per harvest unit. Returns a tuple of lists containing gross revenue
    for each period at [0] and total cost for each period at [1]."""
    grev = ["r", 0, 0, 0, 0]
    cost = ["c", 0, 0, 0, 0]
    for fragment in frags:
        if frags[fragment][3] != 999:
            addc = rxf[frags[fragment][1]][frags[fragment][3]][frags[fragment][2]][13]
            grev[per[frags[fragment][3]]] = grev[per[frags[fragment][3]]] \
                                            + (rxe[frags[fragment][1]][frags[fragment][3]][2] * frags[fragment][2])
            cost[per[frags[fragment][3]]] = cost[per[frags[fragment][3]]] \
                                            + (rxe[frags[fragment][1]][frags[fragment][3]][3] * frags[fragment][2])
            cost[per[frags[fragment][3]]] = cost[per[frags[fragment][3]]] + addc
    return [grev, cost]

def calcton(rxe, frags, per):
    """Calculates the product outputs (merch and pulp) of the current solution. Returns a tuple of
    lists containing merch weight for each period at [0] and pulp weight for each period at [1]."""
    mton = ["m", 0, 0, 0, 0]
    pton = ["p", 0, 0, 0, 0]
    for fragment in frags:
        if frags[fragment][3] != 999:
            mton[per[frags[fragment][3]]] = mton[per[frags[fragment][3]]] \
                                            + (rxe[frags[fragment][1]][frags[fragment][3]][4] * frags[fragment][2])
            pton[per[frags[fragment][3]]] = pton[per[frags[fragment][3]]] \
                                            + (rxe[frags[fragment][1]][frags[fragment][3]][5] * frags[fragment][2])
    return [mton, pton]

def calcnrv(grev, cost):
    """Calculates the net revenue per period. Returns an ordered list."""
    nrev = ["n", 0, 0, 0, 0]
    nrev[1] = grev[1] - cost[1]
    nrev[2] = grev[2] - cost[2]
    nrev[3] = grev[3] - cost[3]
    nrev[4] = grev[4] - cost[4]
    return nrev

def calccov(obj, nrev, grev, mton, pton, cfs):
    """Calculates the current value of the objective function and returns it. Valid obj settings:
    0 - Net revenue
    1 - Gross revenue
    2 - Volume removed
    3 - Combined fire resistance scores"""
    if obj == 0:
        cov = sum(nrev[1:])
    if obj == 1:
        cov = sum(grev[1:])
    if obj == 2:
        cov = sum(mton[1:])
        cov = cov + sum(pton[1:])
    if obj == 3:
        cov = sum(cfs)
    return cov

def calcact(frags, per):
    """Calculates the number of acres being treated in each period. Returns an ordered list."""
    act = ["a", 0.0, 0.0, 0.0, 0.0]
    for fragment in frags:
        if frags[fragment][3] != 999:
            act[per[frags[fragment][3]]] = act[per[frags[fragment][3]]] + frags[fragment][2]
    return act

def disablerx(init, frags, etd, spd, frl, disl):
    """Disables prescriptions in the disable list (disl) by removing them from the dictionaries used to generate solutions
    and moves. Does not return an object."""
    if init == 1:
        remcount = 0
        remacres = 0
        for rx in disl:
            for stand in etd:
                if rx in etd[stand]:
                    etd[stand].remove(rx)
                    l = len(etd[stand])
                    if l < 2:
                        remcount = remcount + 1
                        for fragment in frags:
                            if frags[fragment][1] == stand:
                                remacres = remacres + frags[fragment][2]
                                frl.remove(frags[fragment][0])
        ldisl = len(disl)
        print(str(ldisl) + " prescriptions disabled.")
        print("{:,}".format(remcount) + " stands no longer have a valid treatment, removing " + "{:,}".format(remacres) + " acres from analysis.")
    if init == 3:
        remcount = 0
        remacres = 0
        for rx in disl:
            for stand in spd:
                if rx in spd[stand]:
                    spd[stand].remove(rx)
                    l = len(spd[stand])
                    if l < 2:
                        remcount = remcount + 1
                        for fragment in frags:
                            if frags[fragment][1] == stand:
                                remacres = remacres + frags[fragment][2]
                                frl.remove(frags[fragment][0])
        ldisl = len(disl)
        print(str(ldisl) + " prescriptions disabled.")
        print("{:,}".format(remcount) + " stands no longer have a valid treatment, removing " + "{:,}".format(remacres) + " acres from analysis.")
    
def gensol(init, frags, etd, spd, frl):
    """Generates a solution appropriate for one of the operating modes. Does not return an object.
    0 - Generates a random solution from all treatments
    1 - Generates a random solution from all treatments not in the disabled list (disl)
    2 - Generates a random solution from all self-paying treatments
    3 - Generates a random solution from all self-paying treatments not in the disabled list (disl)
    999 - Generates a no-action solution."""
    print("")
    print("----- GENERATING FULLY RANDOM SOLUTION -----")
    if init == 0 or init == 1:
        for fragment in frags:
            rrx = random.choice(etd[frags[fragment][1]])
            frags[fragment][3] = rrx
    if init == 2 or init == 3:
        for fragment in frags:
            rrx = random.choice(spd[frags[fragment][1]])
            frags[fragment][3] = rrx
    if init == 999:
        for fragment in frags:
            frags[fragment][3] = 999

def updatelim(eyield, st, ac, rrx, rpe, rxf):
    """Updates the even flow yield during limited solution generation. Returns the updated eyield."""
    ny = list(eyield)
    if ny[0] == "n":
        ny[rpe] = ny[rpe] + (rxf[st][rrx][ac][2] - rxf[st][rrx][ac][3])
    elif ny[0] == "a":
        ny[rpe] = ny[rpe] + ac
    elif ny[0] == "r":
        ind = 2
    elif ny[0] == "m":
        ind = 4
    elif ny[0] == "p":
        ind = 5
    if ny[0] != "n" and ny[0] != "a":
        ny[rpe] = ny[rpe] + rxf[st][rrx][ac][ind]
    return ny

def randomlim(ranmoves, actlim, emode, frags, rxd, ranl, rxf, per):
    """Generates the random portion of a limited solution. rxd should be set to etd when
    spmode = 0 and spd when spmode = 1. Returns a tuple containing:
    - A list with the current act at [0], the current count at [1], and the number of moves
    rejected for violating acre constraints at [2], and
    - The current eyield or an 'x' if even flow constraints are disabled."""
    count = 0
    vioac = 0
    act = ["a", 0.0, 0.0, 0.0, 0.0]
    if emode == 1:
        eyield = ["n", 0.0, 0.0, 0.0, 0.0]
    elif emode == 2:
        eyield = ["r", 0.0, 0.0, 0.0, 0.0]
    elif emode == 3:
        eyield = ["m", 0.0, 0.0, 0.0, 0.0]
    elif emode == 4:
        eyield = ["p", 0.0, 0.0, 0.0, 0.0]
    elif emode == 5:
        eyield = list(act)
    while count < ranmoves:
        cf = ranl[count]
        st = frags[cf][1]
        ac = frags[cf][2]
        rrx = random.choice(rxd[st])
        if rrx == 999:
            frags[cf][3] = rrx
        else:
            rpe = per[rrx]
            if actlim[rpe] == -1:
                frags[cf][3] = rrx
                act = updatelim(act, st, ac, rrx, rpe, rxf)
                if emode != 0:
                    eyield = updatelim(eyield, st, ac, rrx, rpe, rxf)
            if actlim[rpe] != -1:
                amact = act[rpe] + ac
                if amact <= actlim[rpe]:
                    frags[cf][3] = rrx
                    act = updatelim(act, st, ac, rrx, rpe, rxf)
                    if emode != 0:
                        eyield = updatelim(eyield, st, ac, rrx, rpe, rxf)
                elif amact > actlim[rpe]:
                    frags[cf][3] = 999
                    vioac = vioac + 1
        count = count + 1
    o1 = [act, count, vioac]
    if emode == 0:
        o2 = "x"
    else:
        o2 = eyield
    return [o1, o2]

def genptd(ranl, frags, rxd, per):
    """Generates a dictionary of applicable treatments keyed by standID and period of application.
    Used during even flow solution generation. Returns a dictionary."""
    ptd = dict()
    for fragment in ranl:
        if frags[fragment][1] not in ptd:
            st = frags[fragment][1]
            ptd[st] = dict()
            for rx in rxd[st]:
                if rx != 999:
                    rxp = per[rx]
                    if rxp not in ptd[st]:
                        ptd[st][rxp] = list()
                    ptd[st][rxp].append(rx)
    return ptd

def guidedlim(count, leng, act, actlim, eyield, frags, rxd, ranl, rxf, per):
    """Generates the guided portion of a limited solution. rxd should be set to etd
    when spmode = 0 and set to spd when spmode = 1. Returns a list containing an act at [0],
    successful guided moves at [1], fragments unable to improve the minimum and set to 999
    at [2], and the eyield at [3]."""
    ranl = ranl[count:]
    ptd = genptd(ranl, frags, rxd, per)
    gmove = 0
    nmove = 0
    while count < leng:
        if eyield != "x":
            minper = eyield.index(min(eyield))
        else:
            minper = act.index(min(act))
        looper = 0
        found = 0
        cleng = len(ranl)
        while looper < cleng:
            cf = ranl[looper]
            st = frags[cf][1]
            if minper not in ptd[st]:
                looper = looper + 1
            else:
                ac = frags[cf][2]
                amact = act[minper] + ac
                if amact > actlim[minper] and actlim[minper] != -1:
                    looper = looper + 1
                else:
                    rrx = random.choice(ptd[st][minper])
                    frags[cf][3] = rrx
                    act = updatelim(act, st, ac, rrx, minper, rxf)
                    if eyield != "x":
                        eyield = updatelim(eyield, st, ac, rrx, minper, rxf)
                    gmove = gmove + 1
                    looper = cleng + 1
                    ranl.remove(cf)
                    found = 1
        if looper >= cleng and found == 1:
            count = count + 1
        elif looper >= cleng and found == 0:
            count = leng + 1
            for fragment in ranl:
                frags[fragment][3] = 999
                nmove = nmove + 1
    out = [act, gmove, nmove, eyield]
    return out       

def genlimsol(ranf, actlim, emode, spmode, frags, etd, spd, frl, rxf, per):
    """Generates a semi-random solution subject to area control and/or even flow limitations, returns
    a tuple containing a list of acres treated per period at [0] and the per period yield subject to
    the even flow constraint at [1]."""
    print("")
    print("----- GENERATING LIMITED SOLUTION -----")
    ranl = list(frl)
    random.shuffle(ranl)
    ranf = ranf / 100.0
    leng = len(ranl)
    ranmoves = ranf * leng
# Generates random partial solution appropriate for spmode
    if spmode == 0:
        randout = randomlim(ranmoves, actlim, emode, frags, etd, ranl, rxf, per)
    elif spmode == 1:
        randout = randomlim(ranmoves, actlim, emode, frags, spd, ranl, rxf, per)
# Unpacking randomlim outputs
    unp = randout[0]
    act = unp[0]
    count = unp[1]
    vioac = unp[2]
    eyield = randout[1]
    print("Random portion of limited solution generated by attempting " + str(count) + " moves.")
    print(str(vioac) + " random moves rejected for violating area control constraints (fragments set to 999).")
# Generates guided partial solution appropriate for spmode
    if spmode == 0:
        guideout = guidedlim(count, leng, act, actlim, eyield, frags, etd, ranl, rxf, per)
    if spmode == 1:
        guideout = guidedlim(count, leng, act, actlim, eyield, frags, spd, ranl, rxf, per)
# Unpacking guidedlim outputs
    act = guideout[0]
    gmove = guideout[1]
    nmove = guideout[2]
    eyield = guideout[3]
    print("Guided portion of limited solution generated by making " + str(gmove) + " moves.")
    print(str(nmove) + " fragments auto-filled with no action alternative due to constraint limitations.")

def gennoise(noise, frags, frl):
    """Moves the solution away from area control limitations by randomly reassigning a given
    percent of stands to the no-action alternative. Does not return an object."""
    ranl = list(frl)
    random.shuffle(ranl)
    leng = len(ranl)
    endp = (leng * noise) + 1
    endp = int(endp)
    ranl = ranl[:endp]
    for fragment in ranl:
        frags[fragment][3] = 999

def savesol(frags):
    """Saves the current solution as a list of prescriptions ordered by fragment number. Returns the list."""
    l = len(frags)
    sol = list()
    count = 0
    while count < l:
        sol.append(frags[count][3])
        count = count + 1
    return sol
    
def loadsol(sol, frags):
    """Replaces the current solution with a previously saved solution. Does not return an object."""
    count = 0
    l1 = len(frags)
    l2 = len(sol)
    if l1 == l2:
        while count < l1:
            frags[count][3] = sol[count]
            count = count + 1
    else:
        print("THE GOGGLES! THEY DO NOTHING!")

def genmove(frags, frl, etd, rxf, per):
    """Selects a random stand that can be moved and finds a random valid move. Does not allow moving to
    the stand's current prescription. Returns an ordered list containing the effects of the move."""
    fr = random.choice(frl)
    st = frags[fr][1]
    ac = frags[fr][2]
    crx = frags[fr][3]
    prx = list(etd[st])
    prx.remove(crx)
    nrx = random.choice(prx)
    if crx != 999:
        ope = per[crx]
    else:
        ope = 0
    if nrx != 999:
        npe = per[nrx]
    else:
        npe = 0
    mef = [nrx, st, fr, ope]
    if ope != 0:
        og = rxf[st][crx][ac][2]
        mef.append(og)
        oc = rxf[st][crx][ac][3] + rxf[st][crx][ac][13]
        mef.append(oc)
        om = rxf[st][crx][ac][4]
        mef.append(om)
        op = rxf[st][crx][ac][5]
        mef.append(op)
    else:
        mef.extend([0.0, 0.0, 0.0, 0.0])
    mef.append(npe)
    if npe != 0:
        ng = rxf[st][nrx][ac][2]
        mef.append(ng)
        nc = rxf[st][nrx][ac][3] + rxf[st][nrx][ac][13]
        mef.append(nc)
        nm = rxf[st][nrx][ac][4]
        mef.append(nm)
        np = rxf[st][nrx][ac][5]
        mef.append(np)
    else:
        mef.extend([0.0, 0.0, 0.0, 0.0])
    se1 = rxf[st][nrx][ac][6] - rxf[st][crx][ac][6]
    se2 = rxf[st][nrx][ac][7] - rxf[st][crx][ac][7]
    se3 = rxf[st][nrx][ac][8] - rxf[st][crx][ac][8]
    se4 = rxf[st][nrx][ac][9] - rxf[st][crx][ac][9]
    se5 = rxf[st][nrx][ac][10] - rxf[st][crx][ac][10]
    mef.extend([se1, se2, se3, se4, se5])
    return mef

def genbounds(cyield, even):
    """Generates the upper and lower bounds as a function of the average yield per period.
    Returns a tuple containing the upper bound at [0] and the lower bound at [1]."""
    ny = list(cyield)
    ue = 1 + even
    le = 1 - even
    tot = ny[1] + ny[2] + ny[3] + ny[4]
    ave = tot / 4
    ub = ave * ue
    lb = ave * le
    return [ub, lb]

def testbounds(cyield, ub, lb, tp):
    """Tests the yield in a test period against the appropriate upper and lower bounds, returns a fin variable."""
    fin = 0
    if tp == 1:
        if cyield[tp] > ub or cyield[tp] < lb:
            fin = 1
    return fin

def calcdev(cyield):
    """Calculates the total deviation for a solution given the yields, upper, and lower bounds. Returns
    the deviation as a float."""
    tot = cyield[1] + cyield[2] + cyield[3] + cyield[4]
    ave = tot / 4
    dis1 = abs(ave - cyield[1])
    dis2 = abs(ave - cyield[2])
    dis3 = abs(ave - cyield[3])
    dis4 = abs(ave - cyield[4])
    dev = dis1**2 + dis2**2 + dis3**2 + dis4**2
    return dev

def testeven(emode, even, mef, cyield, frags):
    """Tests even flow constraint by comparing the effects of a new move to the
    current per period yields. Returns an accept variable at [0] and a fin variable at [1].
    Valid mode settings are:
    1 - Net Revenue
    2 - Gross Revenue
    3 - Merch Volume
    4 - Pulp Volume
    5 - Treated acres"""
    oc = list(cyield)
    nc = list(cyield)
    op = mef[3]
    np = mef[8]
    accept = 0
    fin = 0
    if emode == 1:
        oy = mef[4] - mef[5]
        ny = mef[9] - mef[10]
    elif emode == 2:
        oy = mef[4]
        ny = mef[9]
    elif emode == 3:
        oy = mef[6]
        ny = mef[11]
    elif emode == 4:
        oy = mef[7]
        ny = mef[12]
    elif emode == 5:
        oy = frags[mef[2]][2]
        ny = frags[mef[2]][2]
    if op != 0:
        nc[op] = nc[op] - oy
    if np != 0:
        nc[np] = nc[np] + ny
    bounds = genbounds(nc, even)
    ub = bounds[0]
    lb = bounds[1]
    fin = testbounds(nc, ub, lb, op)
    if fin != 1:
        fin = testbounds(nc, ub, lb, np)
    if fin == 1:
        accept = -2
        odev = calcdev(oc)
        ndev = calcdev(nc)
        if ndev < odev:
            accept = -1
    return [accept, fin]

def testactl(act, actlim, mef, frags):
    """Tests the move against acre treatment limitations. Returns an accept variable at [0]
    and a fin variable [1]."""
    ac = frags[mef[2]][2]
    np = mef[8]
    accept = 0
    fin = 0
    amact = act[np] + ac
    if amact > actlim[np]:
        accept = -3
        fin = 1
    return [accept, fin]

def evalmove(obj, spmode, almode, actlim, emode, even, flood, mef, nrev, grev, cost, mton, pton, act):
    """Evaluates the effects of move against the current solution for a given objective and set of
    evaluation criteria. Returns a tuple containing an accept value at [0] and the current flood at [1].
    Accept values are
    -2 - Rejected for violating constraints
    -1 - Accepted for moving solution closer to meetingconstraints
    0 - Rejected for failing to improve objective function
    1 - Accepted for improving objective function
    2 - Accepted as an allowable disimprovement to objective function
    Valid obj settings are
    0 - Maximize net revenue
    1 - Maximize gross revenue
    2 - Maximize total volume removed
    3 - Maximize total composite resistance score
    Valid spmode settings are
    0 - Accept moves regardless of net income
    1 - Accept only moves with positive net income
    Valid almode settings are
    0 - Acres treated limitations disabled
    1 - Acres treated limitations enabled
    Valid emode settings are
    0 - Even flow constraint disabled
    1 - Apply even flow to net revenue
    2 - Apply even flow to gross revenue
    3 - Apply even flow to merch biomass
    4 - Apply even flow to pulp biomass
    5 - Apply even flow to treated acres"""
    accept = 0
    fin = 0
    imp = 0
    if almode == 1 and mef[0] != 999:
        actlres = testactl(act, actlim, mef, frags)
        accept = actlres[0]
        fin = actlres[1]
# spmode block
    if fin == 0 and spmode == 1:
        if mef[10] > mef[9]:
            fin = 1
        if mef[10] <= mef[9]:
            if mef[5] > mef[4]:
                accept = 1
                fin = 1
# Net revenue even flow block
    if fin == 0 and emode == 1:
        evenres = testeven(emode, even, mef, nrev, frags)
        accept = evenres[0]
        fin = evenres[1]
# Gross revenue even flow block
    if fin == 0 and emode == 2:
        evenres = testeven(emode, even, mef, grev, frags)
        accept = evenres[0]
        fin = evenres[1]
# Merch biomass even flow block
    if fin == 0 and emode == 3:
        evenres = testeven(emode, even, mef, mton, frags)
        accept = evenres[0]
        fin = evenres[1]
# Pulp biomass even flow block
    if fin == 0 and emode == 4:
        evenres = testeven(emode, even, mef, pton, frags)
        accept = evenres[0]
        fin = evenres[1]
# Treatment acres even flow block
    if fin == 0 and emode == 5:
        evenres = testeven(emode, even, mef, act, frags)
        accept = evenres[0]
        fin = evenres[1]
# Maximize net revenue block
    if fin == 0 and obj == 0:
        onrev = mef[4] - mef[5]
        nnrev = mef[9] - mef[10]
        if nnrev >= onrev:
            accept = 1
            imp = nnrev - onrev
        else:
            onrev = onrev - flood
            if nnrev >= onrev:
                accept = 2
            else:
                fin = 1
# Maximize gross revenue block
    if fin == 0 and obj == 1:
        ogrev = mef[4]
        ngrev = mef[9]
        if ngrev >= ogrev:
            accept = 1
            imp = ngrev - ogrev
        else:
            ogrev = ogrev - flood
            if ngrev >= ogrev:
                accept = 2
            else:
                fin = 1
# Maximize volume removed block
    if fin == 0 and obj == 2:
        owt = mef[6] + mef[7]
        nwt = mef[11] + mef[12]
        if nwt >= owt:
            accept = 1
            imp = nwt - owt
        else:
            owt = owt - flood
            if nwt >= owt:
                accept = 2
            else:
                fin = 1
# Maximize resistance score block
    if fin == 0 and obj == 3:
        crs = sum(mef[13:])
        if crs >= 0:
            accept = 1
            imp = crs
        else:
            crs = crs + flood
            if crs >= 0:
                accept = 2
            else:
                fin = 1
# Flood Update
    if accept == 1 and imp != 0:
        reset = flood * 10
        if flood == 0:
            flood = 0.99 * imp
        elif imp > reset:
            flood = 0.99 * imp
        else:
            flood = flood - (imp * 0.5)
        if flood < 0:
            flood = 0
    return [accept, flood]

def updatecov(obj, cov, mef):
    """Updates the current objective function. Returns new cov. Valid obj settings:
    0 - Net revenue
    1 - Gross revenue
    2 - Volume removed
    3 - Combined fire resistance scores"""
    ncov = cov
    if obj == 0:
        ncov = ncov - (mef[4] - mef[5]) + (mef[9] - mef[10])
    if obj == 1:
        ncov = ncov - mef[4] + mef[9]
    if obj == 2:
        ncov = ncov - (mef[6] + mef[7]) + (mef[11] + mef[12])
    if obj == 3:
        ncov = ncov + sum(mef[13:])
    return ncov

def updateyield(cyield, mef):
    """Updates current yield lists to reflect the effects of an accepted move. Returns
    the updated list."""
    ny = list(cyield)
    if ny[0] == "r":
        ind1 = 4
        ind2 = 9
    elif ny[0] == "c":
        ind1 = 5
        ind2 = 10
    elif ny[0] == "m":
        ind1 = 6
        ind2 = 11
    elif ny[0] == "p":
        ind1 = 7
        ind2 = 12
    elif ny[0] == "n":
        ind1 = 4
        ind2 = 5
        ind3 = 9
        ind4 = 10
    op = mef[3]
    np = mef[8]
    if op != 0 and ny[0] != "n":
        ny[op] = ny[op] - mef[ind1]
    if np != 0 and ny[0] != "n":
        ny[np] = ny[np] + mef[ind2]
    if op != 0 and ny[0] == "n":
        ny[op] = ny[op] - (mef[ind1] - mef[ind2])
    if np != 0 and ny[0] == "n":
        ny[np] = ny[np] + (mef[ind3] - mef[ind4])
    return ny

def updatecfs(cfs, mef):
    """Updates current combined fire score list to reflect the effects of an accepted move.
    Returns the updated list."""
    ncfs = list(cfs)
    ncfs[0] = ncfs[0] + mef[13]
    ncfs[1] = ncfs[1] + mef[14]
    ncfs[2] = ncfs[2] + mef[15]
    ncfs[3] = ncfs[3] + mef[16]
    ncfs[4] = ncfs[4] + mef[17]
    return ncfs

def updateact(act, mef, frags):
    """Updates the current tally of treated acres per period to reflect the effects of an
    accepted move. Returns the updated list."""
    nact = list(act)
    op = mef[3]
    np = mef[8]
    ac = frags[mef[2]][2]
    if op != 0:
        nact[op] = nact[op] - ac
    if np != 0:
        nact[np] = nact[np] + ac
    return nact

def calcdelivered(frags, rxf, per, fcl):
    """Calculates the biomass per period delivered to each of the processing facilities.
    Returns a dictionary of lists keyed by facility ID."""
    fcl.sort()
    deld = dict()
    for facility in fcl:
        ind0 = "d" + str(facility)
        deld[facility] = [ind0, 0.0, 0.0, 0.0, 0.0]
    for fragment in frags:
        st = frags[fragment][1]
        ac = frags[fragment][2]
        rx = frags[fragment][3]
        if rxf[st][rx][ac][4] > 0:
            fac = rxf[st][rx][ac][11]
            dp = per[rx]
            deld[fac][dp] = deld[fac][dp] + rxf[st][rx][ac][4]
        if rxf[st][rx][ac][5] > 0:
            fac = rxf[st][rx][ac][12]
            dp = per[rx]
            deld[fac][dp] = deld[fac][dp] + rxf[st][rx][ac][5]
    return deld    

def printout(olist):
    outlist = list(olist)
    for index in outlist:
        out = str(index)
        fhandle.write(out + "\t")
    fhandle.write("\n")
    
# ----- NEO-PROCESSOR -----
# On/off switch to disable optimization while using the testing ground.
optimize = 1
if optimize == 1:
# ----- SYSTEM CONTROLS, SET INDIVIDUAL RUN SETTINGS HERE -----
# - init determines the initial solution. See gensol() notation for full description.
# - mpf is the moves per fragment.
# - movein is the mobilization cost in dollars per harvest operation.
# - obj sets the objective funtion, 0 is maximizing net revenue, 1 is maximizing gross revenue,
#   2 is maximizing volume removal, 3 is maximizing total composite resistance score.
# - spmode modifies move acceptance, automatically rejecting debt incurring moves and automatically accepting
#   debt reducing moves without consideration of the objective function.
# - almode modifes move acceptance, enforcing per period maximum acres treated limitations
# - even modifies move acceptance to apply even flow constraints to a yield or the number of acres treated
# - ranf determines what percent of a limited solution should be randomly generated
# - noise determines what percent of stands will be set to the no action alternative when noise generation is triggered
# - noiset determines how many moves have to be rejected due to area control constraints before noise generation is triggered
# - actlim is a list of the maximum number of acres that can be treated in each period
    init = 0
    disl = []
    mpf = 1000
    fragsize = 100
    biop = 0.0
    adac = 0.0
    ents = 100.0
    fixc = 500.0
    disl = []
    obj = 0
    spmode = 1
    emode = 5
    even = 20.0
    almode = 1
    actlim = ["l", 100000, 100000, 100000, 100000]
    ranf = 50.0
    noise = 10.0
    noiset = 20000
# ----- END OF SYSTEM CONTROLS. ABANDON HOPE ALL YE WHO PASS THIS NOTE -----
    rlist = genfrags(fragsize, "acres.txt", rxe)
    frags = rlist[0]
    nas = rlist[1]
    frl = rlist[2]
    fcount = rlist[3]
    oac = rlist[4]
    nac = rlist[5]
    tac = rlist[6]
    rxf = evalfrags(frags, rxe, etd, tac, adac, fixc, ents)
    if biop != 0:
        pricebio(biop, rxf)
    dcount = len(disl)
    dissettings = [1, 3]
    if dcount >= 1 and init not in dissettings:
        print("")
        print("----- WARNING -----")
        print("To disable prescriptions you must set 'init' to 1 or 3.")
    if dcount >= 1:
        disablerx(init, frags, etd, spd, frl, disl)
    tmc = fcount * mpf
    flood = 0
    count = 0
    even = even / 100
    if emode == 0 and almode == 0:
        gensol(init, frags, etd, spd, frl)
    else:
        genlimsol(ranf, actlim, emode, spmode, frags, etd, spd, frl, rxf, per)
    if almode == 1:
        noise = noise / 100
    cfs = calccfs(0, rxe, frags, nas, tac)
    naa = calccfs(999, rxe, frags, nas, tac)
    econ = calcecn(rxe, frags, per)
    gtwt = calcton(rxe, frags, per)
    grev = list(econ[0])
    cost = list(econ[1])
    mton = list(gtwt[0])
    pton = list(gtwt[1])
    nrev = calcnrv(grev, cost)
    act = calcact(frags, per)
    cov = calccov(obj, nrev, grev, mton, pton, cfs)
    impc = 0
    floc = 0
    fail = 0
    conm = 0
    conf = 0
    actf = 0
    bcov = 0
    ntrig = 0
    maden = 0
    while count < tmc:
        mef = genmove(frags, frl, etd, rxf, per)
        eval = evalmove(obj, spmode, almode, actlim, emode, even, flood, mef, nrev, grev, cost, mton, pton, act)
        accept = eval[0]
        flood = eval[1]
        if accept == 1:
            frags[mef[2]][3] = mef[0]
            grev = updateyield(grev, mef)
            cost = updateyield(cost, mef)
            mton = updateyield(mton, mef)
            pton = updateyield(pton, mef)
            nrev = updateyield(nrev, mef)
            cfs = updatecfs(cfs, mef)
            act = updateact(act, mef, frags)
            cov = updatecov(obj, cov, mef)
            impc = impc + 1
            if cov > bcov:
                bcov = cov
                bsol = savesol(frags)
                bnrev = list(nrev)
                bgrev = list(grev)
                bcost = list(cost)
                bmton = list(mton)
                bpton = list(pton)
                bact = list(act)
                bcfs = list(cfs)
        elif accept == -1:
            frags[mef[2]][3] = mef[0]
            grev = updateyield(grev, mef)
            cost = updateyield(cost, mef)
            mton = updateyield(mton, mef)
            pton = updateyield(pton, mef)
            nrev = updateyield(nrev, mef)
            cfs = updatecfs(cfs, mef)
            act = updateact(act, mef, frags)
            cov = updatecov(obj, cov, mef)
            conm = conm + 1
            bcov = cov
            bsol = savesol(frags)
            bnrev = list(nrev)
            bgrev = list(grev)
            bcost = list(cost)
            bmton = list(mton)
            bpton = list(pton)
            bact = list(act)
            bcfs = list(cfs)               
        elif accept == 2:
            frags[mef[2]][3] = mef[0]
            grev = updateyield(grev, mef)
            cost = updateyield(cost, mef)
            mton = updateyield(mton, mef)
            pton = updateyield(pton, mef)
            nrev = updateyield(nrev, mef)
            cfs = updatecfs(cfs, mef)
            act = updateact(act, mef, frags)
            cov = updatecov(obj, cov, mef)
            floc = floc + 1
        elif accept == 0:
            fail = fail + 1
        elif accept == -2:
            conf = conf + 1
        elif accept == -3:
            actf = actf + 1
            ntrig = ntrig + 1
            if ntrig == noiset:
                gennoise(noise, frags, frl)
                cfs = calccfs(0, rxe, frags, nas, tac)
                econ = calcecn(rxe, frags, per)
                gtwt = calcton(rxe, frags, per)
                grev = list(econ[0])
                cost = list(econ[1])
                mton = list(gtwt[0])
                pton = list(gtwt[1])
                nrev = calcnrv(grev, cost)
                act = calcact(frags, per)
                cov = calccov(obj, nrev, grev, mton, pton, cfs)
                maden = maden + 1
                ntrig = 0
        else:
            print("YOU MONSTERS, YOU BLEW IT UP.")
        count = count + 1
    
# ----- OUTPUTS -----
    print("")
    print("----- OUTPUTS -----")
    if obj == 0:
        print("Maximizing net revenue with a final flood value of " + str(flood))
    if obj == 1:
        print("Maximizing gross revenue with a final flood value of " + str(flood))
    if obj == 2:
        print("Maximizing biomass removed with a final flood value of " + str(flood))
    if obj == 3:
        print("Maximizing combined resistance score with a final flood value of " + str(flood))
    if init == 0:
        print("Initial solution generated randomly from all appropriate treatments.")
    if init == 1:
        print("Initial solution generated randomly from self-paying treatments only.")
    if init == 2:
        print("Initial solution sets all fragments to their no-action alternative.")
    print("Best objective function value: " + "{:,}".format(bcov))
    print("Accepted improvements: " + "{:,}".format(impc))
    print("Accepted disimprovements: " + "{:,}".format(floc))
    print("Rejected disimprovements: " + "{:,}".format(fail))
    if emode != 0:
        print("Disimprovements accepted to reach feasibility: " + "{:,}".format(conm))
        print("Moves rejected for infeasibility or failing to move towards feasibility: " + "{:,}".format(conf))
    if almode != 0:
        print("Moves rejected for violating per period treatment limits: " + "{:,}".format(actf))
        print("Noise generation triggered " + "{:,}".format(maden) + " times.")
    print("")
    if cov != bcov:
        loadsol(bsol, frags)
    fout = dict()
    fhandle = open("fragsout.txt", "w") 
    for fragment in frags:
        if frags[fragment][3] not in fout:
            fout[frags[fragment][3]] = 0.0
        fout[frags[fragment][3]] = fout[frags[fragment][3]] + frags[fragment][2]
        outlist = list(frags[fragment])
        for index in outlist:
            out = str(index)
            fhandle.write(out + "\t")
        fhandle.write("\n")
    fhandle.close()
    print("Individual fragment prescriptions written out to fragsout.txt.")
    print("")
    ttac = 0.0
    rxl.sort()
    for rx in rxl:
        if rx in fout:
            print("{:,}".format(fout[rx]) + " acres assigned to Rx " + str(rx))
            if rx != 999:
                ttac = ttac + fout[rx]
    pert = (ttac / oac) * 100
    print("{:,}".format(ttac) + " acres treated total (" + "{:,}".format(pert) + "% of potentially treatable acres.)")
    print("")
    print("Total acres treated in each period for the best solution: ")
    print("{:,}".format(bact[1]))
    print("{:,}".format(bact[2]))
    print("{:,}".format(bact[3]))
    print("{:,}".format(bact[4]))
    print("")
    print("Per period net revenue of best solution: ")
    print("{:,}".format(bnrev[1]))
    print("{:,}".format(bnrev[2]))
    print("{:,}".format(bnrev[3]))
    print("{:,}".format(bnrev[4]))
    print("")
    print("Per period gross revenue of best solution: ")
    print("{:,}".format(bgrev[1]))
    print("{:,}".format(bgrev[2]))
    print("{:,}".format(bgrev[3]))
    print("{:,}".format(bgrev[4]))
    print("")
    print("Merch biomass (green tons) removal of best solution: ")
    print("{:,}".format(bmton[1]))
    print("{:,}".format(bmton[2]))
    print("{:,}".format(bmton[3]))
    print("{:,}".format(bmton[4]))
    print("")
    print("Pulp biomass (green tons) removal of best solution: ")
    print("{:,}".format(bpton[1]))
    print("{:,}".format(bpton[2]))
    print("{:,}".format(bpton[3]))
    print("{:,}".format(bpton[4]))
    print("")
    print("Composite resistance scores for operable acres at years of interest: ")
    ocfs = calcopcfs(0, rxe, frags, oac)
    print("{:,}".format(ocfs[0]))
    print("{:,}".format(ocfs[1]))
    print("{:,}".format(ocfs[2]))
    print("{:,}".format(ocfs[3]))
    print("{:,}".format(ocfs[4]))
    print("")
    print("Composite resistance scores for operable acres under no action alternative: ")
    onaa = calcopcfs(999, rxe, frags, oac)
    print("{:,}".format(onaa[0]))
    print("{:,}".format(onaa[1]))
    print("{:,}".format(onaa[2]))
    print("{:,}".format(onaa[3]))
    print("{:,}".format(onaa[4]))
    print("")
    print("Composite resistance scores for all acres at years of interest: ")
    print("{:,}".format(bcfs[0]))
    print("{:,}".format(bcfs[1]))
    print("{:,}".format(bcfs[2]))
    print("{:,}".format(bcfs[3]))
    print("{:,}".format(bcfs[4]))
    print("")
    print("Composite resistance scores for all acres under no action alternative: ")
    print("{:,}".format(naa[0]))
    print("{:,}".format(naa[1]))
    print("{:,}".format(naa[2]))
    print("{:,}".format(naa[3]))
    print("{:,}".format(naa[4]))
    print("")
    fhandle = open("deliveries.txt", "w")
    deld = calcdelivered(frags, rxf, per, fcl)
    for facility in fcl:
        outlist = list(deld[facility])
        for index in outlist:
            out = str(index)
            fhandle.write(out + "\t")
        fhandle.write("\n")
    fhandle.close()
    print("Delivered biomass in green tons by facility and period written to deliveries.txt.")
        
    

# ----- OUTPUT VERIFICATION ------
# This block is designed to ensure that running totals are being kept properly.
verify = 0
if verify == 1:
    print("")
    print("----- OUTPUT VERIFICATION -----")
    vcfs = calccfs(0, rxe, frags, nas, tac)
    vecon = calcecn(movein, rxe, frags, per)
    vgtwt = calcton(rxe, frags, per)
    vgrev = list(vecon[0])
    vcost = list(vecon[1])
    vmton = list(vgtwt[0])
    vpton = list(vgtwt[1])
    vnrev = calcnrv(vgrev, vcost)
    vcov = calccov(obj, vnrev, vgrev, vmton, vpton, vcfs)
    print("Recalculated best objective function value: " + "{:,}".format(vcov))
    print("Recalculated per period net revenue of best solution: ")
    print(vnrev)
    print("Recalculated per period gross revenue of best solution: ")
    print(vgrev)
    print("Recalculated per period merch volume removal of best solution: ")
    print(vmton)
    print("Recalculated per period pulp volume removal of best solution: ")
    print(vpton)
    print("Recalculated composite resistance scores at years of interest: ")
    print(vcfs)


# ----- TESTING GROUND -----
if optimize == 0:
    print("")
    print("----- TESTING GROUND -----")
    init = 0
    mpf = 1000
    fragsize = 1000
    biop = 1.0
    adac = 2.0
    fixc = 500.0
    ents = 100.0
    obj = 3
    spmode = 0
    emode = 1
    even = 100
    disl = []
    rlist = genfrags(fragsize, "acres.txt", rxe)
    frags = rlist[0]
    nas = rlist[1]
    frl = rlist[2]
    fcount = rlist[3]
    oac = rlist[4]
    nac = rlist[5]
    tac = rlist[6]
    rxf = evalfrags(frags, rxe, etd, tac, adac, fixc, ents)
    ranf = 50
    print(rxf["1200541010503500712050001"][301])
    pricebio(biop, rxf)
    print(rxf["1200541010503500712050001"][301])
#    actlim = ["l", -1, -1, -1, -1]
    genlimsol(ranf, actlim, emode, spmode, frags, etd, spd, frl, rxf, per)
#    print(guideout)
    econ = calcecn(rxe, frags, per)
    print(econ)
#    fhandle = open("diag.txt", "w")
#    for fragment in frags:
#        outlist = list(frags[fragment])
#        printout(outlist)
#    fhandle.close()
        
        

    
#ncfs = calccfs(999, rxe, frags, nas, tac)
#gensol(init, frags, etd, spd, frl, disl)
#print(rxe["1200541010503500712050001"])
#cfs = calccfs(0, rxe, frags, nas, tac)
#print(ncfs)
#print(cfs)
#econ = calcecn(movein, rxe, frags, per)
#grev = econ[0]
#cost = econ[1]
#nrev = calcnrv(grev, cost)
#gtwt = calcton(rxe, frags, per)
#print(nrev)
#econ = calcecn(movein,rxe,frags,per)
#grev = econ[0]
#cost = econ[1]
#nrev = calcnrv(grev, cost)
#print(nrev)
#grev = econ[0]
#cost = econ[1]
#nrev = calcnrv(grev, cost)
#mton = gtwt[0]
#pton = gtwt[1]
#print(grev)
#print(cost)
#print(mton)
#print(pton)
#print(nrev)
#cov = calccov(obj, nrev, grev, mton, pton, cfs)
#print(cov)
#print(len(frl))
#sol = savesol(frags)
#le = len(sol)
#print(le)
#mef = genmove(movein, frags, frl, etd, rxf)
#print(mef)
#print(frags[mef[2]])
#print(ccfs)
#etest = evalmove(obj, spmode, even, flood, mef, nrev, grev, cost, mton, pton)
#flood = etest[1]
#accept = etest[0]
#if accept == 1:
#    grev = updateyield(grev, mef)
#    cost = updateyield(cost, mef)
#    mton = updateyield(mton, mef)
#    pton = updateyield(pton, mef)
#    nrev = updateyield(nrev, mef)
#    cfs = updatecfs(cfs, mef)
#    print(grev)
#    print(cost)
#    print(mton)
#    print(pton)
#    print(nrev)
#    tcov = updatecov(obj, cov, mef)
#    print(tcov)
#    cov = calccov(obj, nrev, grev, mton, pton, cfs)
#    print(cov)
#print(etest)



#rstand = random.choice(ost)
#print(rxf[rstand][101][50.0])
#print(etd[rstand])
#rrx = random.choice(etd[rstand])
#print(rrx)
#rrx = random.choice(etd[rstand])
#print(rrx)
#print(rxe[rstand][rrx])
#print(per[101])
