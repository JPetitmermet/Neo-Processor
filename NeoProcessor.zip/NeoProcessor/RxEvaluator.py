#!/usr/bin/env python2.7
import io
import random
import cmath
import numpy
import os
import sys
from numbers import Number
os.chdir(os.path.dirname(sys.argv[0]))
os.chdir("rxe_parameters")

# ----- DICTIONARY DEFINITIONS AND LOADING -----

# "s[x]" dictionaries store board foot volume of a log with a given top dib and length
# se and s1 should always be empty
# Called with slist[length][topdib]
# Length is in four foot segments

s1 = dict()         
s2 = dict()
s3 = dict()
s4 = dict()
s5 = dict()
s6 = dict()
s7 = dict()

slist = [0, s1, s2, s3, s4, s5, s6, s7]
llist = [8,12,16,20,24,28]

fhandle = io.open("scribtable.txt", "r")
for line in fhandle:
    tlist = line.strip().split("\t")
    k = int(tlist[0])
    a = float(tlist[1])
    b = float(tlist[2])
    c = float(tlist[3])
    d = float(tlist[4])
    e = float(tlist[5])
    f = float(tlist[6])
    s2[k] = a
    s3[k] = b
    s4[k] = c
    s5[k] = d
    s6[k] = e
    s7[k] = f
fhandle.close()

# "c[x]" dictionaries hold prices per mbf by species and top dib
# ce should always be empty
# Called with clist[tree eater species code][dclass]
# PSME = 1
# CADE = 2
# PIPO = 3
# PILA = 4
# PICO = 5
# TFIR = 6

c1 = {8:481.25, 14:513.75, 22:526.25, 24:532.50}
c2 = {8:635.00, 14:635.00, 22:635.00, 24:635.00}
c3 = {8:282.50, 14:316.25, 22:345.00, 24:377.50}
c4 = {8:275.00, 14:295.00, 22:330.00, 24:345.00}
c5 = {8:342.50, 14:342.50, 22:342.50, 24:342.50}
c6 = {8:377.50, 14:391.25, 22:410.00, 24:416.25}

clist = [0, c1, c2, c3, c4, c5, c6]

# eqict takes FIA species codes and returns the tree eater species code
eqdict = {11:6, 15:6, 17:6, 19:6, 20:6, 21:6, 81:2, 108:5, 116:3, 117:4, 122:3, 202:1}

# dib lists contain the parameters neccessary for dib calculations
# See preptable.xlsx for list of indexes
# Call with mdib[species code][index]

dib1 = list()         
dib2 = list()
dib3 = list()
dib4 = list()
dib5 = list()
dib6 = list()

mdib = [0, dib1, dib2, dib3, dib4, dib5, dib6]

fhandle = io.open("dibparms.txt", "r")
parc = 1
for line in fhandle:
    tlist = line.strip().split("\t")
    mdib[parc].append(float(tlist[0]))
    mdib[parc].append(float(tlist[1]))
    mdib[parc].append(float(tlist[2]))
    mdib[parc].append(float(tlist[3]))
    mdib[parc].append(float(tlist[4]))
    mdib[parc].append(float(tlist[5]))
    mdib[parc].append(float(tlist[6]))
    mdib[parc].append(float(tlist[7]))
    parc = parc + 1
fhandle.close()

# Loading parameters for calculating green weight values

gwp = dict()
fhandle = io.open("gwtparms.txt", "r")
for line in fhandle:
    tlist = line.strip().split("\t")
    a = int(tlist[0])
    b = float(tlist[1])
    c = float(tlist[2])
    d = float(tlist[3])
    e = float(tlist[4])
    f = float(tlist[5])    
    gwp[a] = [b, c, d, e, f]
fhandle.close()

# Mortality parameters for calculating predicted mortality portion

mrt = dict()
fhandle = io.open("mrtparms.txt", "r")
for line in fhandle:
    tlist = line.strip().split("\t")
    a = int(tlist[0])
    count = 1
    mrt[a] = list()
    while count < 8:
        b = float(tlist[count])
        mrt[a].append(b)
        count = count + 1
fhandle.close()

# Mill capability data
mcap = dict()
pfac = list()
facl = list()
fhandle = io.open("fcap.txt", "r")
for line in fhandle:
    tlist = line.strip().split("\t")
    a = int(tlist[0])
    facl.append(a)
    if tlist[3] == "S":
        b = 1
    elif tlist[3] == "P":
        b = 0
        pfac.append(a)
    else:
        print("WARNING: ONE OR MORE FACILITY HAS NO VALID MATERIAL")
    c = int(tlist[4])
    d = int(tlist[5])
    e = int(tlist[6])
    f = int(tlist[7])
    g = int(tlist[8])
    h = int(tlist[9])
    mcap[a] = [b, c, d, e, f, g, h]
fhandle.close()    
    
# Travel cost data
travel = dict()
ninel = [999.9]
for fac in mcap:
    ninel.append(999.9)
fhandle = io.open("tcost.txt", "r")
for line in fhandle:
    tlist = line.strip().split("\t")
    a = str(tlist[0])
    b = int(tlist[1])
    c = float(tlist[2])
    if a not in travel:
        travel[a] = dict()
        travel[a][0] = list(ninel)
        travel[a][1] = list(ninel)
    if b in pfac:
        travel[a][0][b] = c
    else:
        travel[a][1][b] = c
fhandle.close()

# Yarding data
yard = dict()
fhandle = io.open("yard.txt", "r")
for line in fhandle:
    tlist = line.strip().split("\t")
    a = str(tlist[0])
    b = float(tlist[1])
    c = float(tlist[2])
    yard[a] = [b,c]
fhandle.close()

# ----- FUNCTION DEFINITIONS -----

def disroute(fdisl, travel, pfac):
    """Disables facilities by resetting the transit costs from each stand to the facility to $999.9 per
    green ton. Modifies travel in place and does not return an object."""
    for fac in fdisl:
        count = 0
        if fac in pfac:
            for st in travel:
                travel[st][0][fac] = 999.9
                count = count + 1
        if fac not in pfac:
            for st in travel:
                travel[st][1][fac] = 999.9
                count = count + 1
        print("Transport costs for facility " + str(fac) + " set to 999.9 for " + str(count) + " stands.")

def minroute(sp, st, travel, mcap, facl):
    """Finds the minimum cost route given a species and stand of interest, returns that minimum cost."""
    min = 999.9
    for fac in facl:
        if travel[st][1][fac] < min and mcap[fac][sp] == 1:
            min = travel[st][1][fac]
    return min
    

def evaltravel(travel, mcap, pfac, facl):
    """Generates a dictionary (tcost) keyed by stand id and populated with the transport costs in dollars per green ton
    for each material and species. Pulp cost is stored at [0] and saw costs are stored at the index of their tree eater
    species code ([1] through [6]). Returns the completed dictionary."""
    spcl = [1, 2, 3, 4, 5, 6]
    tcost = dict()
    for st in travel:
        tcost[st] = [999.9, 999.9, 999.9, 999.9, 999.9, 999.9, 999.9]
        tcost[st][0] = min(travel[st][0])
        for sp in spcl:
            tcost[st][sp] = minroute(sp, st, travel, mcap, facl)
    return tcost

def gendib(tree, height, mdib):
    """gendib takes a commercial tree entry and determines the diameter inside bark at a given height.
    PICO equation taken from the corrected Garber and Maguire 2002, all others from Hann 2016."""
    if tree[9] != 5:
        cs = tree[9]
        pdib = (mdib[cs][0] * (tree[1] ** mdib[cs][1])) * cmath.exp((mdib[cs][2]) * ((1 - tree[4]) ** 0.5))
        hd = (tree[2] - 4.5) / tree[1]
        height = height - 4.5
        rh = height / (tree[2] - 4.5)
        wlt = (mdib[cs][7] * tree[11] - 4.5) / (tree[2] - 4.5)
        i1 = 0
        i2 = 0
        if rh >= 0 and wlt >= rh:
            i1 = 0
        if wlt < rh and rh <= 1:
            i1 = 1
        if wlt <= 0:
            i2 = 0
        if wlt > 0:
            i2 = 1
        jp1 = (rh - 1) / (wlt - 1)
        jp2 = (wlt - rh) / (wlt - 1)
        x1 = mdib[cs][3] + (mdib[cs][4] * cmath.exp(mdib[cs][5] * (hd ** 2)))
        x2 = mdib[cs][6]
        z0 = 1.0 - rh + i2 * (rh + i1 * (jp1 * (1.0 + jp2) - 1.0 )) - (rh - 1) * (rh - i2 * rh)
        z1 = (i2 * (rh + i1 * (jp1 * (rh + (wlt * jp2)) - rh)) - ((rh - 1) * (rh - i2 * rh))) 
        z2 = i2 * ((rh**2) + i1 * (jp1 * wlt * (2 * rh - wlt + (wlt * jp2)) - rh**2))
        dib = pdib * (z0 + (x1 * z1) + (x2 * z2))
        dib = dib.real
    if tree[9] == 5:
        cs = tree[9]
        mdbh = tree[1] * 2.54
        mht = tree[2] / 3.28084
        height = height / 3.28084
        z = height / mht
        q = 1 - z**0.5
        p = 1.37 / mht
        x = q / (1 - p**0.5)
        d = (mdbh**2) / mht
        c = (mdib[cs][1] * cmath.asin(q)) + (mdib[cs][2] * cmath.log(x)) + (mdib[cs][3] * cmath.log(z)) + (mdib[cs][4] * cmath.exp(z)) + (mdib[cs][5] * d) + (mdib[cs][6] * cmath.exp(z) * d)
        dib = mdib[cs][0] * mdbh * (x**c)
        dib = dib.real
        dib = dib / 2.54
    return dib

def dibtree(tree, mdib):
    """Takes a tree and populates a list with dibs. First nine indexes (0-8) should be empty.
    Every other index will be filled with the appropriate dib for that height until dib < 4 or
    until it reaches the actual height of the tree"""
    count = 9
    diblist = [0,0,0,0,0,0,0,0,0]
    while count < tree[3]:
        dib = gendib(tree,count,mdib)
        if dib >= 4:
            diblist.append(dib)
            count = count + 1
        if dib < 4:
            count = 999
    return diblist

def pricelog(topdib, length, species, slist, clist):
    """Takes a log with a given topdib, length, and species and returns a price for that log."""
    bf = slist[length/4][int(topdib)]
    mbf = bf / 1000
    if topdib >= 6 and topdib <= 8:
        pbracket = 8
    if topdib > 8 and topdib <= 14:
        pbracket = 14
    if topdib > 14 and topdib <= 22:
        pbracket = 22
    if topdib > 22 and topdib <= 24:
        pbracket = 24
    p = mbf * clist[species][pbracket]
    return p

def gennodes(maxht):
    """Generates an empty node list for use in bucking."""
    count = 0
    nodes = list()
    while count <= maxht + 1:
        nodes.append(0)
        count = count + 1
    return nodes

def evalnode(tree, diblist, nodes, cnode, llist, maxht):
    """Evaluates all potential logs coming from a single node and saves the value of those logs in the forward node.
    Carries values current node forward where appropriate."""
    for length in llist:
        if cnode + length <= maxht:
            tnode = cnode + length + 1
            if diblist[tnode-1] >= 6:
                tval = pricelog(diblist[tnode-1], length, tree[9], slist, clist)
                pathval = tval + nodes[cnode]
            else:
                pathval = nodes[cnode]
            if nodes[tnode] < pathval:
                nodes[tnode] = pathval
    return nodes

def evaltree(tree, mdib, clist, slist, llist):
    """Takes a tree and generates a dibtree, then bucks that tree and values the outputs.
    Returns a nodelist with the optimal value for in each node.
    Whole tree value in $/cf is stored in index 0 of the nodelist."""
    diblist = dibtree(tree, mdib)
    maxht = len(diblist) - 1
    maxnode = maxht - 8
    nodes = gennodes(maxht)
    count = 1
    while count <= maxnode:
        nodes = evalnode(tree, diblist, nodes, count, llist, maxht)
        count = count + 1
    bestval = max(nodes)
    nodes[0] = bestval * (1 - tree[5])
    nodes[1] = bestval
    return nodes

def evalpulp(tree, nodes, mdib):
    """Takes a bucked tree and finds the lowest node with the optimal value.
    Uses that node to calculate the remaining volume to a four inch top and (if possible) create a pulp log.
    Pulp logs must be at least eight feet long and may go down to a diameter inside bark of four inches.
    Returns the cubic foot volume of any pulp log found in [0], non-log pulp in [1]."""
    optval = nodes[1]
    maxht = len(nodes) - 1
    count = 9
    pulp = [0,0]
    pulplen = 0
    while count <= maxht:
        if nodes[count] != optval:
            count = count + 1
        elif nodes[count] == optval:
            optht = count
            count = maxht + 1
            pulplen = maxht - optht
    if pulplen >= 8:
        pulptop = gendib(tree,maxht,mdib)
        pulpbot = gendib(tree,optht,mdib)
        r1 = pulptop / 24
        r2 = pulpbot / 24
        pulp[0] = (numpy.pi * pulplen * ((r1**2) + (r2**2) + (r1*r2))) / 3
        pulp[0] = pulp[0] * (1 - tree[5])
    if pulplen < 8:
        pulptop = gendib(tree,maxht,mdib)
        pulpbot = gendib(tree,optht,mdib)
        r1 = pulptop / 24
        r2 = pulpbot / 24
        pulp[1] = (numpy.pi * pulplen * ((r1**2) + (r2**2) + (r1*r2))) / 3
        pulp[1] = pulp[1] * (1 - tree[5])
    return pulp            

def calcbarkwt(volume, spcd, mc, gwp):
    """Takes a volume and species code and returns the green weight of bark in pounds. Requires gwp.
    Positive moisture content values set moisture content to that percent.
    Negative moisture content values will reduce FIADB moisture content values by that value (to a minimum of 10%).
    Set moisturecontent to zero to use FIADB moisture content values.
    Will print an error and return a weight of zero if species is not present in gwp."""
    barkwt = 0
    if spcd not in gwp:
        print("Species code " + str(spcd) + " not found in green weight parameters.")
    if spcd in gwp and mc > 0:
        mc = float(mc)
        barkwt = volume * 62.4 * gwp[spcd][2] * (gwp[spcd][0]/(100 + gwp[spcd][0])) * (1 + mc/100)
    if spcd in gwp and mc == 0:
        barkwt = volume * 62.4 * gwp[spcd][2] * (gwp[spcd][0]/(100 + gwp[spcd][0])) * (1 + gwp[spcd][4]/100)
    if spcd in gwp and mc < 0:
        mc = float(mc)
        mc = gwp[spcd][4] + mc
        if mc >= 10.0:
            barkwt = volume * 62.4 * gwp[spcd][2] * (gwp[spcd][0]/(100 + gwp[spcd][0])) * (1 + mc/100)
        else:
            barkwt = volume * 62.4 * gwp[spcd][2] * (gwp[spcd][0]/(100 + gwp[spcd][0])) * 1.1
    return barkwt

def calcwoodwt(volume, spcd, mc, gwp):
    """Takes a volume and species code and returns the green weight of wood in pounds. Requires gwp.
    Positive moisture content values set moisture content to that percent.
    Negative moisture content values will reduce FIADB moisture content values by that value (to a minimum of 10%).
    Set moisturecontent to zero to use FIADB moisture content values.
    Will print an error and return a weight of zero if species is not present in gwp."""
    woodwt = 0
    if spcd not in gwp:
        print("Species code " + str(spcd) + " not found in green weight parameters.")
    if spcd in gwp and mc != 0:
        mc = float(mc)
        woodwt = volume * 62.4 * gwp[spcd][1] * (1 - gwp[spcd][0]/(100 + gwp[spcd][0])) * (1 + mc/100)
    if spcd in gwp and mc == 0:
        woodwt = volume * 62.4 * gwp[spcd][1] * (1 - gwp[spcd][0]/(100 + gwp[spcd][0])) * (1 + gwp[spcd][3]/100)
    if spcd in gwp and mc < 0:
        mc = float(mc)
        mc = gwp[spcd][3] + mc
        if mc >= 10.0:
            woodwt = volume * 62.4 * gwp[spcd][1] * (1 - gwp[spcd][0]/(100 + gwp[spcd][0])) * (1 + mc/100)
        else:
            woodwt = volume * 62.4 * gwp[spcd][1] * (1 - gwp[spcd][0]/(100 + gwp[spcd][0])) * 1.1
    return woodwt

def incut(rx, woodmc, barkmc, filename, eqdict, gwp, mdib, clist, slist, llist):
    """incut imports a cutlist file and creates a pair of dictionaries, one of bucked tree records [0],
    one of per acre outputs by stand [1]. Requires unpacking."""
    trx = dict()
    orx = dict()
    tcount = 0
    scount = 0
    fhandle = io.open(filename, "r")
    for line in fhandle:
# Initial input processing and cut tree creation
        tlist = line.strip().split("\t")
        a = int(tlist[0])
        b = float(tlist[1])
        c = float(tlist[2])
        d = float(tlist[3])
        if d < 1:
            d = c
        e = float(tlist[4]) * 0.01
        f = float(tlist[5]) * 0.01
        g = float(tlist[6])
        h = float(tlist[7])
        i = str(tlist[8])
        if a not in eqdict:
            j = 0
        if a in eqdict:
            j = eqdict[a]
        if isinstance(tlist[9],Number):
            k = int(tlist[9])
        else:
            k = str(tlist[9])
        cht = d * e
        l = d - cht
        m = int(tlist[10])
        n = int(rx)
        tree = [a, b, c, d, e, f, g, h, i, j, k, l, m, n]
# Cut tree testing (species, size, and ability to create a merch log) and creation of Tprice, MerchVol, and PulpVol
        eval = 1
        if tree[9] == 0:
            eval = 0
        if tree[1] < 6 or tree[1] > 24:
            eval = 0
        if eval == 1:
            f9 = gendib(tree, 9.0, mdib)
            if f9 < 6:
                eval = 0
        if eval == 0:
            tree.extend([0,0,tree[7],0])
        if eval == 1:
            nodes = evaltree(tree, mdib, clist, slist, llist)
            pulp = evalpulp(tree, nodes, mdib)
            tree.append(nodes[0])
            tree.append(pulp[1])
            tree.append(pulp[0])
            tree.append(((tree[7] * (1 - tree[5])) - pulp[1]) - pulp[0])
        if tree[16] > 0:
            pbark = calcbarkwt(tree[16],tree[0],barkmc,gwp)
            pwood = calcwoodwt(tree[16],tree[0],woodmc,gwp)
            ptotal = pbark + pwood
            ptons = ptotal / 2000
            tree.append(ptons)
        else:
            tree.append(0.0)
        if tree[17] > 0:
            mbark = calcbarkwt(tree[17],tree[0],barkmc,gwp)
            mwood = calcwoodwt(tree[17],tree[0],woodmc,gwp)
            mtotal = mbark + mwood
            mtons = mtotal / 2000
            tree.append(mtons)
        else:
            tree.append(0.0)      
# Storing cut tree in appropriate stand dictionary and creating that dictionary if it does not already exist
        if tree[8] not in trx:
            trx[tree[8]] = dict()
            scount = scount + 1
        trx[tree[8]][tree[10]] = tree
        tcount = tcount + 1
# Adds cut tree values to existing Per Acre Outputs,
        if tree[8] not in orx:
            orx[tree[8]] = [rx,tree[8],0,0,0,0,0]
        orx[tree[8]][2] = orx[tree[8]][2] + (tree[14] * tree[6])
        orx[tree[8]][3] = orx[tree[8]][3] + (tree[17] * tree[6])
        orx[tree[8]][4] = orx[tree[8]][4] + (tree[16] * tree[6])
        orx[tree[8]][5] = orx[tree[8]][5] + (tree[19] * tree[6])
        orx[tree[8]][6] = orx[tree[8]][6] + (tree[18] * tree[6])
    fhandle.close()
    print(str(tcount) + " cut tree records across " + str(scount) + " stands loaded for Rx " + str(rx))
    return [trx, orx]

def loadprx(rx, filename, orx):
    """Loads potfire variables into a nested dictionary (prx) and returns the loaded dictionary.
    Only loads values for stands with cut tree records and the no action alternative.
    Only loads values for years of interest (years 1, 6, 11, 16, and 20)"""
    y = [1,6,11,16,20]
    scount = 0
    prx = dict()
    fhandle = io.open(filename, "r")
    for line in fhandle:
        tlist = line.strip().split("\t")
        a = str(tlist[0])
        if rx == 999 or a in orx[rx]:
            b = int(tlist[1])
            if b in y:
                if a not in prx:
                    prx[a] = dict()
                    scount = scount + 1
                c = float(tlist[2])
                d = float(tlist[3])
                prx[a][b] = [rx, a, b, c, d]
    print("Potfire values for " + str(scount) + " stands loaded for Rx " + str(rx))
    return prx

def loadhrx(rx, filename, orx):
    """Loads data from the queried structure class table and finds the weighted average height
    to crown base (single strata stands) or the height between the top of the lowest stratum and the
    bottom of the next to lowest stratum (multi-strata stands). Only loads values for years of interest
    (years 1, 6, 11, 16, and 20) and stands of interest (all stands in 999 and treated stands
    in any other prescription)."""
    y = [1,6,11,16,20]
    scount = 0
    hrx = dict()
    fhandle = io.open(filename, "r")
    for line in fhandle:
        tlist = line.strip().split("\t")
        a = str(tlist[0])
        b = int(tlist[1])
        if rx == 999 or a in orx[rx]:
            if a not in hrx:
                hrx[a] = dict()
                scount = scount + 1
            if b in y:
                c = float(tlist[2])
                c = int(c)
                if c == 1 or c == 0:
                    d = float(tlist[3])
                    d = int(d)
                    hrx[a][b] = [rx, a, b, c, d]
                elif c == 2:
                    d = float(tlist[4]) - float(tlist[5])
                    d = int(d)
                    hrx[a][b] = [rx, a, b, c, d]
                elif c == 3:
                    d = float(tlist[6]) - float(tlist[7])
                    d = int(d)
                    hrx[a][b] = [rx, a, b, c, d]
                else:
                    print("DANGER, DANGER WILL ROBINSON")
    print("Structure class values for " + str(scount) + " stands loaded for Rx " + str(rx))
    return hrx

def calcmort(species, dbh, volume, mrt):
    """Takes the volume of a tree record and returns the predicted volume mortality."""
    if dbh < 5:
        mort = volume * mrt[species][0]
    if dbh >= 5 and dbh < 10:
        mort = volume * mrt[species][1]
    if dbh >= 10 and dbh < 15:
        mort = volume * mrt[species][2]
    if dbh >= 15 and dbh < 21:
        mort = volume * mrt[species][3]
    if dbh >= 21 and dbh < 30:
        mort = volume * mrt[species][4]
    if dbh >= 30 and dbh < 40:
        mort = volume * mrt[species][5]
    if dbh >= 40:
        mort = volume * mrt[species][6]
    return mort        
        
def intree(rx, filename, trx, prx, hrx, mrt):
    """Loads trees from FVS tree lists and calculates relevant stand level values.
    Only loads leave tree records for stands that are treated and the no action alternative.
    Only loads values for years of interest (years 1, 6, 11, 16, and 20.
    Returns a tuple of dictionaries that must be unpacked. Trees are [0] stands are [1])."""
    scount = 0
    tcount = 0
    lrx = dict()
    srx = dict()
    y = [1,6,11,16,20]
    rbalist = [20,21,116,117,122,202]
    treattime = {101:1, 201:1, 301:1, 401:1, 501:1, 601:1,
                 102:6, 202:6, 302:6, 402:6, 502:6, 602:6,
                 103:11, 203:11, 303:11, 403:11, 503:11, 603:11,
                 104:16, 204:16, 304:16, 404:16, 504:16, 604:16}
    fhandle = io.open(filename, "r")
    for line in fhandle:
        tlist = line.strip().split("\t")
        d = str(tlist[8])
# Check if we care about the tree at all
        if rx == 999 or d in trx[rx]:
            eval = 1
            f = int(tlist[10])
            c = float(tlist[6])
            if isinstance(tlist[9],Number):
                e = int(tlist[9])
            else:
                e = str(tlist[9])
            if f not in y:
                eval = 0
# Check if tree record is cut, leave it out if whole record is cut, calculate remaining tpa if not
            if rx != 999 and eval == 1:
                if f == treattime[rx]:
                    if e in trx[rx][d]:
                        ctpa = trx[rx][d][e][6]
                        if ctpa == c:
                            eval = 0
                        else:
                            c = c - ctpa
# If there is some amount of tree record left...
            if eval == 1:
# Check if proper dictionaries exist, build them if not                
                if d not in lrx:
                    lrx[d] = dict()
                if e not in lrx[d]:
                    lrx[d][e] = dict()
                    tcount = tcount + 1
                if d not in srx:
                    srx[d] = dict()
                    scount = scount + 1
                if f not in srx[d]:
                    srx[d][f] = [rx, d, f, 0, 0, 0, 0, 0, 0]
# Build rest of tree record
                a = int(tlist[0])
                b = float(tlist[1])
                g = float(tlist[7])
                h = (b**2) * 0.005454
                treeyear = [a, b, c, d, e, f, g, h, rx]
# Store it
                lrx[d][e][f] = treeyear
# Calculated and add stand level data
                srx[d][f][3] = srx[d][f][3] + treeyear[7] * treeyear[2]
                if treeyear[0] in rbalist:
                    srx[d][f][4] = srx[d][f][4] + treeyear[7] * treeyear[2]
                if srx[d][f][5] == 0:
                    try:
                        srx[d][f][5] = hrx[rx][d][f][4]
                    except:
                        srx[d][f][5] = 100.0
                if srx[d][f][6] == 0:
                    srx[d][f][6] = prx[rx][d][f][4]
                srx[d][f][7] = srx[d][f][7] + treeyear[6] * treeyear[2]
                srx[d][f][8] = srx[d][f][8] + calcmort(treeyear[0], treeyear[1], treeyear[6]*treeyear[2], mrt)
    print(str(tcount) + " leave tree records across " + str(scount) + " stands loaded for Rx " + str(rx)) 
    return [lrx,srx]

def costst(pao, slopebp, yard, trx, tcost):
    """Takes the per acre outputs for a single stand and calculates the per acre harvest cost.
    Calculates time per acre, (f/ht) and cost (f/h/lc). bp is the breakpoint between low
    slope and high slope (slope >= bp will use tethered equations). Returns per acre costs as a list."""
    # Constants
    lpp = 35.29 # Pulp loading rate, green tonnes / hr
    lsp = 59.42 # Saw loading rate, green tonnes / hr
    hdi = 531  # Two way distance (in meters) required for harvester to treat one acre (25 ft boom reach)
    wpb = 12    # Tonnes per bunk
    # Taking data from objects
    rx = pao[0]
    st = pao[1]
    sac = pao[5]
    pac = pao[6]
    fdi = yard[st][1]
    # Metric conversion for modeling
    sac = sac * 0.907185
    pac = pac * 0.907185
    tw = sac + pac
    fdi = fdi * 0.3048
    # Bunk count calculation
    bca = tw / wpb
    bca = round(bca)
    fdi = fdi * bca * 2
    # Forwarder minimum distance (30 ft boom reach and 30 meters outside corridor to nearest pile)
    if fdi < 473:
        fdi = 473
    # Tether cost calculation
    if yard[st][0] >= slopebp:
        ht = (1.43 * tw) + (.25 * hdi)
        hc = ht / 60 * 278.95
        ft = (.05 * fdi) + (2.19 * sac) + (4.06 * pac)
        fc = ft / 60 * 198.11
    # Untethered cost calculation        
    else:
        ht = (1.43 * tw) + (.25 * hdi)
        hc = ht / 60 * 212.47
        ft = (.01 * fdi) + (2.19 * sac) + (4.06 * pac)
        fc = ft / 60 * 172.22
    # Loading cost calculation
    lpt = pac / lpp
    lst = sac / lsp
    lt = lpt + lst
    lc = lt * 213.22
    mc = 0.0
    for id in trx[rx][st]:
        tree = trx[rx][st][id]
        sp = tree[9]
        if tree[19] == 0:
            pvol = tree[18] * tree[6]
            tpc = pvol * tcost[st][0]
            mc = mc + tpc
        elif tree[18] == 0:
            svol = tree[19] * tree[6]
            tsc = svol * tcost[st][sp]
            mc = mc + tsc
        else:
            pvol = tree[18] * tree[6]
            tpc = pvol * tcost[st][0]
            mc = mc + tpc
            svol = tree[19] * tree[6]
            tsc = svol * tcost[st][sp]
            mc = mc + tsc
    tc = fc + hc + lc + mc
    pac = [rx, st, tc, fc, hc, lc, 0, mc]
    if tw == 0:
        pac[6] = 1
    return pac

def costrx(rx, slopebp, trx, orx, yard, tcost):
    """Takes the per acre outputs for a prescription and generates harvest costs in dollars per acre.
    bp is the breakpoint between low slope and high slope (slope >= bp will use tethered equations).
    Returns a dictionary keyed by stand id."""
    crx = dict()
    scount = 0
    acount = 0
    for stand in orx[rx]:
        crx[stand] = costst(orx[rx][stand], slopebp, yard, trx, tcost)
        scount = scount + 1
        acount = acount + crx[stand][6]
    print("Per acre harvest costs calculated for " + str(scount) + " stands.")
    print("Brushing costs invoked for " + str(acount) + " stands.")
    return crx

def scorest(pal):
    """Takes a per acre leave record and calculates the composite fire score.
    Returns a tuple that must be unpacked with individual scores in a list [0] and the total score [1]."""
    score = list()
    if pal[5] < 7:
        score.append(0)
    elif pal[5] < 20 and pal[5] >= 7:
        score.append(1)
    elif pal[5] < 30 and pal[5] >= 20:
        score.append(2)
    elif pal[5] >= 30:
        score.append(3)
    if pal[6] > 0.15:
        score.append(0)
    elif pal[6] > 0.1 and pal[6] <= 0.15 :
        score.append(1)
    elif pal[6] > 0.05 and pal[6] <= 0.1:
        score.append(2)
    elif pal[6] <= 0.05:
        score.append(3)
    if pal[3] > 0:
        rbp = pal[4] / pal[3]
        if rbp < 0.25:
            score.append(0)
        if rbp < 0.50 and rbp >= 0.25:
            score.append(1)
        if rbp < 0.75 and rbp >= 0.50:
            score.append(2)
        if rbp >= 0.75:
            score.append(3)
    else:
        score.append(3)
    if pal[7] > 0:
        svp = 1 - (pal[8] / pal[7])
        if svp < 0.02:
            score.append(0)
        elif svp < 0.30 and svp >= 0.02:
            score.append(1)
        elif svp < 0.60 and svp >= 0.30:
            score.append(2)
        elif svp >= 0.60:
            score.append(3)
    else:
        score.append(3)
    crs = sum(score)
    return [score,crs]

def scorerx(rx, srx, orx, crx):
    """Scores all stands in a prescription and brings in the cost and revenue data to generate a final output for optimization.
    Returns a single dictionary."""
    optout = dict()
    scount = 0
    for stand in srx[rx]:
        if rx != 999:
            opt = [rx, stand, orx[rx][stand][2], crx[rx][stand][2], orx[rx][stand][5], orx[rx][stand][6]]
        else:
            opt = [rx, stand, 0.0, 0.0, 0.0, 0.0]
        crs = scorest(srx[rx][stand][1])
        opt.append(crs[1])
        try:
            crs = scorest(srx[rx][stand][6])
        except:
            srx[rx][stand][6] = [rx, stand, 6, 0.0, 1.0, 100.0, 0.0, 0.0, 0.0]
            crs = scorest(srx[rx][stand][6])
        opt.append(crs[1])
        try:
            crs = scorest(srx[rx][stand][11])
        except:
            srx[rx][stand][11] = [rx, stand, 11, 0.0, 1.0, 100.0, 0.0, 0.0, 0.0]
            crs = scorest(srx[rx][stand][11])
        opt.append(crs[1])
        try:
            crs = scorest(srx[rx][stand][16])
        except:
            srx[rx][stand][16] = [rx, stand, 16, 0.0, 1.0, 100.0, 0.0, 0.0, 0.0]
            crs = scorest(srx[rx][stand][16])
        opt.append(crs[1])
        try:
            crs = scorest(srx[rx][stand][20])
        except:
            srx[rx][stand][20] = [rx, stand, 20, 0.0, 1.0, 100.0, 0.0, 0.0, 0.0]
            crs = scorest(srx[rx][stand][20])
        opt.append(crs[1])
        opt.append(999)
        opt.append(999)
        optout[stand] = opt
        scount = scount + 1
    print(str(scount) + " stands scored for Rx " + str(rx))
    return optout

def loadblock(rx, mcbark, mcwood, slopebp, eqdict, gwp, mdib, clist, slist, llist, mrt, yard, tcost):
    """Loads prescription data and calculates the necessary outputs. Returns the optout object
    for the loaded prescription."""
    strx = str(rx)
    trx = dict()
    orx = dict()
    prx = dict()
    hrx = dict()
    lrx = dict()
    srx = dict()
    crx = dict()
    print("")
    print("----- LOADING " + strx + " BLOCK ------")
    if rx != 999:
        cfile = strx + "c.txt"
        cut = incut(rx,mcbark,mcwood,cfile,eqdict,gwp,mdib,clist,slist,llist)
        trx[rx] = cut[0]
        orx[rx] = cut[1]
        crx[rx] = costrx(rx, slopebp, trx, orx, yard, tcost)
    pfile = strx + "p.txt"
    prx[rx] = loadprx(rx, pfile, orx)
    sfile = strx + "s.txt"
    hrx[rx] = loadhrx(rx, sfile, orx)
    lfile = strx + "l.txt"
    leave = intree(rx,lfile,trx, prx, hrx, mrt)
    lrx[rx] = leave[0]
    srx[rx] = leave[1]
    optout = scorerx(rx, srx, orx, crx)
    return optout

os.chdir(os.path.dirname(sys.argv[0]))
os.chdir("rxe_FVSinputs")
    
# ----- RX EVALUATOR -----
# On/off switch for diagnostics
evaluate = 1
if evaluate == 1:
# ----- USER CONTROLS -----
# mcbark and mcwood set the assumed moisture content for bark and wood respectively.
# See documentation for full description of moisture content settings.
# slopebp sets the breakpoint for tethered vs untethered operations.
# rxlist contains all prescriptions to be analyzed.
# fdisl is a disable list for turning off certain facilities (by facility id).
    mcbark = 0
    mcwood = 0
    slopebp = 35
    rxlist = [101, 102, 103, 104, \
              201, 202, 203, 204, \
              301, 302, 303, 304, \
              401, 402, 403, 404, \
              501, 502, 503, 504, \
              601, 602, 603, 604, 999]
    fdisl = []
# END OF USER CONTROLS
    lenfd = len(fdisl)
    if lenfd > 0:
        disroute(fdisl, travel, pfac)
    tcost = evaltravel(travel, mcap, pfac, facl)
    optout = dict()
    for rx in rxlist:
        optout[rx] = loadblock(rx, mcbark, mcwood, slopebp, eqdict, gwp, mdib, clist,\
                               slist, llist, mrt, yard, tcost)


#----- Output Writer ------
    print("")
    print("----- OUTPUT WRITER -----")
    os.chdir(os.path.dirname(sys.argv[0]))
    fhandle = open("rxoutputs.txt", "w")
    ocount = 0
    rcount = 0
    for rx in optout:
        scount = 0
        for stand in optout[rx]:        
            outlist = list(optout[rx][stand])
            for index in outlist:
                out = str(index)
                fhandle.write(out + "\t")
            fhandle.write("\n")
            scount = scount + 1
            ocount = ocount + 1
        rcount = rcount + 1
        print("Outputs written for " + str(scount) + " stands in Rx " + str(rx))
    fhandle.close()
    print(str(ocount) + " potentialities evaluated across " + str(rcount) + " prescriptions.") 

# ----- TESTING GROUND -----
if evaluate == 0:
    print("-----TESTING GROUND OUTPUTS-----")
    mcbark = 0
    mcwood = 0
    bp = 35
    trx = dict()
    orx = dict()
    prx = dict()
    hrx = dict()
    lrx = dict()
    srx = dict()
    crx = dict()
    optout = dict()


    

# BLOCK
#print("")
#print("BLOCK")
#tempt = incut(101,mcbark,mcwood,"101c.txt", eqdict, gwp, mdib, clist, slist, llist)
#trx[101] = tempt[0]
#orx[101] = tempt[1]
#crx[101] = costrx(101, bp, orx, yard)
#prx[101] = loadprx(101, "601p.txt", orx)
#hrx[101] = loadhrx(101, "601s.txt", orx)
#tempt = intree(101,"101l.txt",trx,prx,hrx,mrt)
#lrx[101] = tempt[0]
#srx[101] = tempt[1]
#optout[101] = scorerx(101, srx, orx, crx, route)
#print(srx[101]["1200641010603500820670001"][11])
#fhandle = open("treesout.txt

# 999 BLOCK
#print("")
#print("999 BLOCK")
#prx[999] = loadprx(999, "999p.txt", orx)
#hrx[999] = loadhrx(999, "999s.txt", orx)
#tempt = intree(999,"999l.txt",trx,prx,hrx,mrt)
#lrx[999] = tempt[0]
#srx[999] = tempt[1]
#optout[999] = scorerx(999, srx, orx, crx, route)

#print(orx[101]["1200541010503500851250001"])
#print(srx[101]["1200541010503500851250001"][1])
#print(prx[999]["1200541010503500851250001"][1])
#print("")
#test = scorest(srx[101]["1200541010503500851250001"][1])
#print(test)
#test2 = scorest(srx[101]["1200541010503500851250001"][20])
#print(test2)
#print(optout[101]["1200541010503500851250001"])
#print(optout[999]["1200541010503500851250001"])
#traveltest = travel["1200541010503500851250001"]
#print(traveltest)
#routetest = route["1200541010503500851250001"]
#print(routetest)
#print(yard["1200541010503500851250001"])
#ctest = costst(orx[101]["1200541010503500851250001"],bp,yard)
#print(ctest)

#PURE SUBMERCH CUT

#print(optout[101]["1201306060309300732390001"])
#print(crx[101]["1201306060309300732390001"])
